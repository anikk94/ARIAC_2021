# inherit Task class to create sub tasks


class Task():
    """Completion of the task
    """
    def __init__(self):
        pass

    def task_done(self):
        """Completion of the task
        """
        pass
