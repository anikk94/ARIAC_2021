from moveit_runner import MoveitRunner
from utils.utility import print_partition
from utils.conversion import get_target_world_pose
from utils.utility import get_part_location_in_bins
import rospy
import copy
from time import sleep
from utils.constants import Const

class GantryRobot:
    """Class to represent the atrributes and methods for gantry robot
    """
    # pylint: disable=too-few-public-methods
    gantry_group_names = ['gantry_full', 'gantry_arm', 'gantry_torso']

    def __init__(self, world_model):
        self._world_model = world_model

    @staticmethod
    def go_home():
        """Function for returning gantry
        to original position
        """
        moveit_runner_gantry = MoveitRunner(
                                            GantryRobot.gantry_group_names,
                                            ns='/ariac/gantry')
        moveit_runner_gantry.gantry_status_publisher.publish("init")
        # test code
        # moveit_runner_gantry.goto_preset_location("g_pre_agv1", "gantry_robot")
        # rospy.sleep(5)
        # moveit_runner_gantry.goto_preset_location("g_agv1", "gantry_robot")
        # rospy.sleep(5)
        # moveit_runner_gantry.go_home()
        # rospy.sleep(5)
        # moveit_runner_gantry.goto_preset_location("g_pre_agv2", "gantry_robot")
        # rospy.sleep(5)
        # moveit_runner_gantry.goto_preset_location("g_agv2", "gantry_robot")
        # rospy.sleep(5)
        # moveit_runner_gantry.go_home()
        # rospy.sleep(5)
        # moveit_runner_gantry.goto_preset_location("g_pre_agv3", "gantry_robot")
        # rospy.sleep(1)
        # moveit_runner_gantry.goto_preset_location("g_agv3", "gantry_robot")
        # rospy.sleep(1)
        # moveit_runner_gantry.go_home()
        # rospy.sleep(1)
        # moveit_runner_gantry.goto_preset_location("g_pre_agv4", "gantry_robot")
        # rospy.sleep(1)
        # moveit_runner_gantry.goto_preset_location("g_agv4", "gantry_robot")
        # rospy.sleep(1)
        # moveit_runner_gantry.go_home()
        # rospy.sleep(1)
        
        # moveit_runner_gantry.goto_preset_location("bin4", "gantry_robot")
        # rospy.sleep(1)
        # moveit_runner_gantry.goto_preset_location("bin3", "gantry_robot")
        # rospy.sleep(1)
        # moveit_runner_gantry.go_home()
        # rospy.sleep(1)
        # moveit_runner_gantry.goto_preset_location("bin7", "gantry_robot")
        # rospy.sleep(1)
        # moveit_runner_gantry.goto_preset_location("bin8", "gantry_robot")
        # rospy.sleep(1)
        # moveit_runner_gantry.go_home()
        # rospy.sleep(1)

        # moveit_runner_gantry.goto_preset_location("home1", "gantry_robot")
        # rospy.sleep(1)
        # moveit_runner_gantry.goto_preset_location("before_as1", "gantry_robot")
        # rospy.sleep(1)
        # moveit_runner_gantry.goto_preset_location("agv2_as1", "gantry_robot")
        # rospy.sleep(1)
        # moveit_runner_gantry.goto_preset_location("as1", "gantry_robot")
        # rospy.sleep(1)
        # moveit_runner_gantry.goto_preset_location("agv2_as1", "gantry_robot")
        # rospy.sleep(1)
        # moveit_runner_gantry.goto_preset_location("before_as1", "gantry_robot")
        # rospy.sleep(1)
        # moveit_runner_gantry.goto_preset_location("home1", "gantry_robot")
        # rospy.sleep(1)
        
        # moveit_runner_gantry.goto_preset_location("home1", "gantry_robot")
        # rospy.sleep(1)
        # moveit_runner_gantry.goto_preset_location("before_as3", "gantry_robot")
        # rospy.sleep(1)
        # moveit_runner_gantry.goto_preset_location("as3", "gantry_robot")
        # rospy.sleep(1)
        # moveit_runner_gantry.goto_preset_location("before_as3", "gantry_robot")
        # rospy.sleep(1)
        # moveit_runner_gantry.goto_preset_location("agv4_as3", "gantry_robot")
        # rospy.sleep(1)
        # moveit_runner_gantry.goto_preset_location("before_as3", "gantry_robot")
        # rospy.sleep(1)

        # moveit_runner_gantry.go_home()
        moveit_runner_gantry.goto_preset_location("home1", "gantry_robot")

    def discard_part(self, faulty_dest_part):
        """Start discarding unnecessary parts
        """
        print_partition()
        rospy.loginfo("Discarding Faulty Part.." + faulty_dest_part.type)
        print_partition()
        self.moveit_runner_gantry = MoveitRunner(GantryRobot.
                                                  gantry_group_names,
                                                  ns='/ariac/gantry')
        faulty_dest_part_trash = copy.deepcopy(faulty_dest_part)
        faulty_dest_part_trash.pose.position.x = -2.212158
        faulty_dest_part_trash.pose.position.y = -0.014119
        faulty_dest_part_trash.pose.position.z = 0.828004
        # self.moveit_runner_gantry.pick_part(faulty_dest_part)
        # self.moveit_runner_gantry.throw_part(faulty_dest_part_trash)
        self.moveit_runner_gantry.move_part_gantry(faulty_dest_part.location_type,
                                             faulty_dest_part,
                                             faulty_dest_part_trash,
                                             "trash_bin")
    
    def move_part(self, dest_part, agv_id, dest_part_in_world_pose_flag = False):
        """Reading the data and moving the part
        """
        print_partition()
        rospy.loginfo("MOVING PART for.." + dest_part.type)
        rospy.loginfo(dest_part.pose)
        rospy.loginfo(agv_id)
        rospy.loginfo("dest_part_in_world_pose_flag: " + str(dest_part_in_world_pose_flag))
        print_partition()

        if not dest_part_in_world_pose_flag:
            dest_part = get_target_world_pose(dest_part, agv_id)


        is_part_found = False
        part_found = None
        is_part_found, part_found = self._world_model.search_part_for(dest_part.type)
        
        #Find part in the bins dict such that it returns the bin to


        #Have a common kitting and gantry robot class to select the robot to choose for picking part based on bin
        #Or Have the search part function in make plan for order to obtain the position of the detination part and call move_part for that bin and position

        if is_part_found:
            if (part_found.pose.position.x == 0 and
                part_found.pose.position.y == 0 and
                part_found.pose.position.z == 0):
                print_partition()
                rospy.loginfo("Error: MOVING PART for.." + dest_part.type + " FAILED!")
                print_partition
                return

            part_dest_pos = copy.deepcopy(dest_part)
            bin_type = part_found.location_type
            self.moveit_runner_gantry = MoveitRunner(GantryRobot.
                                                        gantry_group_names,
                                                        ns='/ariac/gantry')
            self.moveit_runner_gantry.move_part_gantry(bin_type, part_found,
                                                    part_dest_pos, agv_id)
        else:
            print_partition()
            rospy.loginfo("NO RELEVANT PART FOUND:" + dest_part.type)
            print_partition()
            return

        print_partition()
        rospy.loginfo("Verifying the Moved Part..")
        print_partition()
        sleep(Const.SLEEP_TIMER)
        self.sanity_check(agv_id)
 

    def sanity_check(self, agv_id):
        """Checking the wokring for faulty part
        """

        agv_robot = self._world_model.get_agv_robot(agv_id)
        flag, faulty_part = self._world_model.search_faulty_part_in(agv_id)

        if flag:
            print_partition()
            rospy.loginfo("Faulty Part Identified by Quality Sensor")
            rospy.loginfo(faulty_part.pose)
            print_partition()

            part_on_agv = copy.deepcopy(agv_robot.find_part_on_tray(faulty_part))
            # orig_part_pos = copy.deepcopy(faulty_part)
            if part_on_agv is not None:
                print_partition()
                rospy.loginfo("Identified FAULTY PART on " + agv_id + ":" + part_on_agv.type)
                rospy.loginfo(part_on_agv.pose)
                print_partition()
                self.discard_part(part_on_agv)

                self.move_part(part_on_agv, agv_id, True)
        else:
            return
        
